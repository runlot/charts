{{/*
Helpers for charts/runlot. Two things only live here: naming, and the env blocks
that more than one workload reads.

**The env variable names are the real ones.** They come from deploy/README.md §3
and deploy/cp/install.sh §4, not from a reading of what they ought to be called.
A chart that invents a name produces a process that comes up with that value
empty, and an empty value is a documented behaviour for most of them -- so the
failure is not a crash, it is a feature quietly off. `RUNLOT_DASHBOARD_URL` and
`RUNLOT_PUBLIC_URL` being one value with three readers is the same point from the
other side.
*/}}

{{- define "runlot.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "runlot.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "runlot.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
app.kubernetes.io/name: {{ include "runlot.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
runlot.io/profile: {{ .Values.profile }}
runlot.io/tier: {{ .Values.tier }}
{{- end -}}

{{- define "runlot.selectorLabels" -}}
app.kubernetes.io/name: {{ include "runlot.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/* image <dict repository tag> -> registry/repository:tag */}}
{{- define "runlot.image" -}}
{{- $tag := .root.Values.images.tag | default .root.Chart.AppVersion -}}
{{- printf "%s/%s:%s" .root.Values.global.imageRegistry .repository $tag -}}
{{- end -}}

{{- define "runlot.imagePullSecrets" -}}
{{- with .Values.global.imagePullSecrets }}
imagePullSecrets:
{{- range . }}
  - name: {{ . }}
{{- end }}
{{- end }}
{{- end -}}

{{/*
The secrets every control-plane process needs, as envFrom-less explicit
secretKeyRefs. Explicit rather than `envFrom: secretRef` because a Secret the
customer created with one extra key would otherwise inject it into our process
environment, and because a missing key then names itself in the pod's events
instead of arriving as an empty string.
*/}}
{{- define "runlot.secretEnv" -}}
{{- include "runlot.customerSecretEnv" . }}
{{ include "runlot.generatedEnv" . }}
{{- end -}}

{{/*
The customer's secrets alone -- what `runlot.secretEnv` carries minus the kept
values. **This is what the install Job gets.** On a first install the generated
Secret is a chart object created *empty* (generated-secret.yaml), and the Job is
the process that fills it; a secretKeyRef on a key that is not there yet is
CreateContainerConfigError, and the pod that was going to write the key never
starts. Measured on kind, 2026-10-04: `couldn't find key internalToken in Secret
runlot-generated`, for ever. The Job reads the kept values back through the API
(RUNLOT_GENERATED_SECRET), not through its environment.
*/}}
{{- define "runlot.customerSecretEnv" -}}
{{- with .Values.metaDB.existingSecret }}
- name: RUNLOT_DATABASE_URL
  valueFrom: {secretKeyRef: {name: {{ . }}, key: url}}
{{- end }}
{{- with .Values.masterKey.existingSecret }}
- name: RUNLOT_MASTER_KEY
  valueFrom: {secretKeyRef: {name: {{ . }}, key: masterKey}}
- name: RUNLOT_MASTER_KEY_VERSION
  value: "1"
{{- end }}
{{- with .Values.objectStore.existingSecret }}
- name: RUNLOT_OBJSTORE_ACCESS_KEY_ID
  valueFrom: {secretKeyRef: {name: {{ . }}, key: accessKeyId}}
- name: RUNLOT_OBJSTORE_SECRET_ACCESS_KEY
  valueFrom: {secretKeyRef: {name: {{ . }}, key: secretAccessKey}}
{{- end }}
{{- with .Values.mail.smtp.existingSecret }}
- name: RUNLOT_MAIL_SMTP_USER
  valueFrom: {secretKeyRef: {name: {{ . }}, key: user, optional: true}}
- name: RUNLOT_MAIL_SMTP_PASSWORD
  valueFrom: {secretKeyRef: {name: {{ . }}, key: password, optional: true}}
{{- end }}
{{- if and .Values.auth.oidc.enabled .Values.auth.oidc.existingSecret }}
- name: RUNLOT_OIDC_CLIENT_SECRET
  valueFrom: {secretKeyRef: {name: {{ .Values.auth.oidc.existingSecret }}, key: clientSecret}}
{{- end }}
{{- end -}}

{{/*
The kept values the running processes read. Never on the install Job: see
runlot.customerSecretEnv.
*/}}
{{- define "runlot.generatedEnv" -}}
- name: RUNLOT_INTERNAL_TOKEN
  valueFrom: {secretKeyRef: {name: {{ include "runlot.fullname" . }}-generated, key: internalToken}}
- name: RUNLOT_OPERATOR_TOKEN
  valueFrom: {secretKeyRef: {name: {{ include "runlot.fullname" . }}-generated, key: operatorToken}}
- name: RUNLOT_SESSION_KEY
  valueFrom: {secretKeyRef: {name: {{ include "runlot.fullname" . }}-generated, key: sessionKey}}
- name: RUNLOT_ACCESS_KEY
  valueFrom: {secretKeyRef: {name: {{ include "runlot.fullname" . }}-generated, key: accessKey}}
- name: RUNLOT_METRICS_TOKEN
  valueFrom: {secretKeyRef: {name: {{ include "runlot.fullname" . }}-generated, key: metricsToken}}
{{- end -}}

{{/*
The non-secret configuration. One block, read by cp-core, cp-public, the install
Job and the migrate Job, because the install core and the processes have to agree
about these values -- the whole point of §4's one core is that a defect which
appears in one caller and not another is in the shell.
*/}}
{{- define "runlot.configEnv" -}}
- name: RUNLOT_STATE_DIR
  value: /var/lib/runlot/cp-state
- name: RUNLOT_CA_DIR
  value: /etc/runlot/ca
{{/*
The deploy bundle store is the customer's bucket, under `artifacts/`. cp-public
writes a bundle and cp-core serves it to the node, and in a cluster those are two
pods with no filesystem in common: with a directory store each had its own
emptyDir, the deploy answered 201 and the node got `artifact … not found` from
cp-core for ever (field notes #117, measured on VKE). RUNLOT_ARTIFACT_DIR is left
unset on purpose -- cp-core and cp-public refuse a `dir` store with no directory,
so a chart that lost this line fails loudly instead of splitting the store again.
*/}}
- name: RUNLOT_ARTIFACT_STORE
  value: objstore
- name: RUNLOT_APP_DOMAIN
  value: {{ .Values.domains.apps | quote }}
- name: RUNLOT_WIRE_DOMAIN
  value: {{ .Values.domains.wire | quote }}
- name: RUNLOT_GIT_DOMAIN
  value: {{ .Values.domains.git | quote }}
- name: RUNLOT_OBJECTS_DOMAIN
  value: {{ .Values.domains.objects | quote }}
{{/*
One value, three readers. RUNLOT_PUBLIC_URL is cp-public's own origin,
RUNLOT_DASHBOARD_URL is the same string reaching cp-core (for the links in
notification mail) and node-front (the access-control login round trip). It is
not that there are three names; it is that there is one value with three
processes reading it.
*/}}
- name: RUNLOT_PUBLIC_URL
  value: https://{{ .Values.domains.dashboard }}
- name: RUNLOT_DASHBOARD_URL
  value: https://{{ .Values.domains.dashboard }}
{{/*
The operations console is the same origin split by Host
(docs/admin-console.md §2.1), so RUNLOT_ADMIN_HOST is the dashboard host.
*/}}
- name: RUNLOT_ADMIN_HOST
  value: {{ .Values.domains.dashboard | quote }}
- name: RUNLOT_ADMIN_EMAILS
  value: {{ join "," .Values.org.adminEmails | quote }}
{{/*
On-prem we issue no certificate. hostnames rows are created and verified with a
CNAME check against the customer's DNS and nothing is minted or carried in the
map; a custom domain's certificate is theirs (docs/onprem-delivery.md §7.4).
*/}}
- name: RUNLOT_CERT_MODE
  value: external
- name: RUNLOT_LICENSE_FILE
  value: /etc/runlot/license/license
{{/*
The licence trust list, for the drill alone. It is rendered only when it is set,
because an empty variable here and no variable at all are the same to the loader
but not to a reviewer reading the manifest: a written-out
`RUNLOT_LICENSE_PUBLIC_KEYS: ""` reads as a knob somebody turned off, and this
one is never meant to be turned on. The loader honours it only while dev auth is
on, which is `environment: dev` and nothing a customer release sets.
*/}}
{{- with .Values.license.publicKeysOverride }}
- name: RUNLOT_LICENSE_PUBLIC_KEYS
  value: {{ . | quote }}
{{- end }}
- name: RUNLOT_SIGNUP
  value: {{ .Values.auth.signup | quote }}
{{- if .Values.auth.oidc.enabled }}
- name: RUNLOT_OIDC_ISSUER
  value: {{ .Values.auth.oidc.issuer | quote }}
- name: RUNLOT_OIDC_CLIENT_ID
  value: {{ .Values.auth.oidc.clientId | quote }}
{{- with .Values.auth.oidc.domains }}
- name: RUNLOT_OIDC_DOMAINS
  value: {{ join "," . | quote }}
{{- end }}
{{- end }}
- name: RUNLOT_OBJSTORE_ENDPOINT
  value: {{ .Values.objectStore.endpoint | quote }}
{{/*
The SigV4 region. Every S3 reader refuses an empty one ("the configuration has
no region") -- node-git crash-looped on the first kind install for exactly that,
2026-10-04 -- and the install core defaults it the same way (us-east-1, what
MinIO and most clones accept).
*/}}
- name: RUNLOT_OBJSTORE_REGION
  value: {{ .Values.objectStore.region | default "us-east-1" | quote }}
{{/*
**RUNLOT_OBJSTORE_BUCKET is not here, deliberately.** It is the one object-store
value that is not the same for every process: node-git backs the repositories up
into `<bucket>-git` and everything else reads and writes `<bucket>`. On a VM that
split is `objBucket, objGitBucket = "runlot", "runlot-git"` in
internal/install/cp.go, and the reason is the key shape -- a git backup's keys
would mix with env.storage's `p/<projectId>/` prefixes in one bucket, and then
neither a lifecycle rule nor a restore could name its own objects. Each workload
includes `runlot.objstoreBucketEnv` or `runlot.objstoreGitBucketEnv` instead.
*/}}
- name: RUNLOT_OBJSTORE_PATH_STYLE
  value: {{ ternary "1" "0" .Values.objectStore.pathStyle | quote }}
- name: RUNLOT_MAIL_SMTP_HOST
  value: {{ .Values.mail.smtp.host | quote }}
- name: RUNLOT_MAIL_SMTP_PORT
  value: {{ .Values.mail.smtp.port | quote }}
- name: RUNLOT_MAIL_SMTP_STARTTLS
  value: {{ default true .Values.mail.smtp.startTLS | quote }}
- name: RUNLOT_MAIL_FROM
  value: {{ .Values.mail.smtp.from | quote }}
{{- with .Values.observability.sentryDsn }}
- name: RUNLOT_SENTRY_DSN
  value: {{ . | quote }}
{{- end }}
{{/*
**The two halves of dev auth, from one value.** cp-core's licence loader decides
whether to honour RUNLOT_LICENSE_PUBLIC_KEYS on `RUNLOT_ENV != "prod"`
(cp/cmd/cp-core/main.go) and cp-public decides the same thing on
RUNLOT_ENABLE_DEV_AUTH. With RUNLOT_ENV unset the first was true in every cluster
while the second was false, so one installation had two answers to "is this a
drill" -- and the half that said yes was the half that picks trust anchors. Both
now come from `environment`, which is a tag on the installation, not a project.

Off, and verified off (§7.9). Each of the rest comes up disabled on an empty
variable, and `runlot-admin preflight` prints the list so that "I thought it was
on" has a line to read. They are written out rather than omitted because an
omitted variable and an empty one are the same to the process but not to a
reviewer reading the rendered manifest.
*/}}
- name: RUNLOT_ENV
  value: {{ .Values.environment | quote }}
- name: RUNLOT_ENABLE_DEV_AUTH
  value: {{ ternary "true" "false" (eq .Values.environment "dev") | quote }}
- name: RUNLOT_CF_API_TOKEN
  value: ""
- name: RUNLOT_DNS_NAMESERVERS
  value: ""
- name: RUNLOT_NAMECOM_USER
  value: ""
- name: RUNLOT_POSTHOG_KEY
  value: ""
- name: RUNLOT_POLAR_TOKEN
  value: ""
{{- end -}}

{{/*
The object-store bucket, per workload. Two helpers rather than one with a
parameter, because what has to be readable in the rendered manifest is which of
the two buckets a given pod writes to.
*/}}
{{- define "runlot.objstoreBucketEnv" -}}
- name: RUNLOT_OBJSTORE_BUCKET
  value: {{ .Values.objectStore.bucket | quote }}
{{- end -}}

{{/*
node-git's own backup bucket, `<bucket>-git`. The VM install writes `runlot-git`
beside `runlot` for the same reason, and **the customer has to create both** --
NOTES.txt says so, because nothing else will.
*/}}
{{- define "runlot.objstoreGitBucketEnv" -}}
- name: RUNLOT_OBJSTORE_BUCKET
  value: {{ printf "%s-git" .Values.objectStore.bucket | quote }}
{{- end -}}

{{/*
The /etc/runlot mounts every control-plane workload shares: a writable /etc/runlot
itself, the licence (read at runtime by the loader) and the private CA that
cp-core writes on first start.
*/}}
{{- define "runlot.cpVolumeMounts" -}}
{{/*
The directory /etc/runlot has to be **writable**, and the image's root
filesystem is not. The
install core writes the site-level env files there -- cp-core.env, cp-public.env,
node-git.env, shared.env -- and with `readOnlyRootFilesystem: true` and no volume
every one of those is an open failure in the install Job.

An emptyDir rather than something that survives: in a cluster those files are the
core's debugging artefact and no process reads them back. What must survive is in
`<fullname>-generated` (the kept secrets) and on the state PVC (the CA, the era).

It is mounted first and the licence and the CA are nested inside it. Kubernetes
mounts a pod's volumes shortest path first, so /etc/runlot is in place before
/etc/runlot/license and /etc/runlot/ca land on top of it.
*/}}
- name: etc
  mountPath: /etc/runlot
- name: license
  mountPath: /etc/runlot/license
  readOnly: true
{{/*
/etc/runlot/ca cannot be a read-only Secret mount: cp-core creates the CA there
on first start (localca.Ensure) and writes its own control leaf beside it. It is a
subPath of the state PVC rather than an emptyDir so that the CA survives a pod
replacement -- a regenerated CA invalidates every node certificate at once, and
`localca.Ensure` refuses to start when ca.crt is present and ca.key is not.
*/}}
- name: state
  mountPath: /etc/runlot/ca
  subPath: ca
- name: state
  mountPath: /var/lib/runlot
  subPath: var
{{- end -}}

{{- define "runlot.cpVolumes" -}}
- name: etc
  emptyDir: {}
- name: license
  secret:
    secretName: {{ .Values.license.existingSecret | default (printf "%s-license" (include "runlot.fullname" .)) }}
    {{/*
    Outside `eval` the schema already refuses an empty licence secret, so this is
    only ever optional on an evaluation install -- where a missing licence makes
    cp-core treat the installation as unlicensed rather than refuse to start.
    */}}
    optional: {{ eq .Values.tier "eval" }}
- name: state
  persistentVolumeClaim:
    claimName: {{ include "runlot.fullname" . }}-cp-state
{{- end -}}
